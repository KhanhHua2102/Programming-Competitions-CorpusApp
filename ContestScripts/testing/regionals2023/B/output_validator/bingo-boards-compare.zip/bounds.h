#ifndef BOUNDS_H
#define BOUNDS_H

const int MIN_N = 1;
const int MAX_N = 200;

const int MIN_K = 0;

#endif  // BOUNDS_H
