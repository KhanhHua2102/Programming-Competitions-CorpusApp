#ifndef BOUNDS_H
#define BOUNDS_H

const int MIN_N = 1, MAX_N = 200000;
const int MIN_M = 0, MAX_M = 200000;
const int MIN_K = 1, MAX_K = 200000;
const int MAX_SUM_K = 400000;

#endif
