#ifndef BOUNDS_H
#define BOUNDS_H

const int MIN_T = 1;
const int MAX_T = 10'000;

const int MIN_XY = -1'000'000'000;
const int MAX_XY = 1'000'000'000;

#endif  // BOUNDS_H
