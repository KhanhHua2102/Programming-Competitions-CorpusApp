#ifndef BOUNDS_H
#define BOUNDS_H

const int MIN_N = 1;
const int MAX_N = 500000;

const int MIN_LR = 1;
const int MAX_LR = 1000000000;

#endif  // BOUNDS_H
